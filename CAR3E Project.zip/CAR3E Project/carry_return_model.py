"""
CAR³E Carry Trade Return Model
Calculates carry trade profitability with risk adjustments
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict
import matplotlib.pyplot as plt
import seaborn as sns


class CarryTradeModel:
    """
    Carry trade profitability model with volatility and drawdown adjustments
    """
    
    def __init__(self, data: pd.DataFrame):
        """
        Initialize carry trade model
        
        Args:
            data: DataFrame with FX rates and interest rates
        """
        self.data = data
        self.carry_returns = None
        
    def calculate_interest_differential(self, 
                                       target_rate: str, 
                                       funding_rate: str) -> pd.Series:
        """
        Calculate interest rate differential
        
        Args:
            target_rate: Column name for target currency rate
            funding_rate: Column name for funding currency rate
            
        Returns:
            Series with interest rate differentials
        """
        return self.data[target_rate] - self.data[funding_rate]
    
    def calculate_fx_returns(self, fx_pair: str, periods: int = 1) -> pd.Series:
        """
        Calculate FX returns
        
        Args:
            fx_pair: FX pair column name
            periods: Number of periods for return calculation
            
        Returns:
            Series with FX returns
        """
        return self.data[fx_pair].pct_change(periods) * 100
    
    def calculate_carry_return(self,
                              fx_pair: str,
                              target_rate: str,
                              funding_rate: str,
                              holding_period: int = 21) -> pd.DataFrame:
        """
        Calculate total carry trade return
        
        Args:
            fx_pair: FX pair column name
            target_rate: Target currency interest rate
            funding_rate: Funding currency interest rate
            holding_period: Holding period in days
            
        Returns:
            DataFrame with carry trade components
        """
        # Interest differential (annualized)
        rate_diff = self.calculate_interest_differential(target_rate, funding_rate)
        
        # Scale to holding period
        carry_component = rate_diff * (holding_period / 252)
        
        # FX return component
        fx_return = self.calculate_fx_returns(fx_pair, holding_period)
        
        # Total return
        total_return = carry_component + fx_return
        
        # Create results DataFrame
        results = pd.DataFrame({
            'rate_differential': rate_diff,
            'carry_component': carry_component,
            'fx_return': fx_return,
            'total_return': total_return
        })
        
        return results
    
    def calculate_volatility_adjusted_return(self,
                                            returns: pd.Series,
                                            window: int = 21) -> pd.Series:
        """
        Calculate volatility-adjusted returns (Sharpe-like metric)
        
        Args:
            returns: Return series
            window: Rolling window for volatility
            
        Returns:
            Volatility-adjusted returns
        """
        rolling_vol = returns.rolling(window=window).std()
        vol_adj_returns = returns / (rolling_vol + 1e-6)  # Add epsilon to avoid division by zero
        
        return vol_adj_returns
    
    def calculate_max_drawdown(self, returns: pd.Series) -> pd.Series:
        """
        Calculate rolling maximum drawdown
        
        Args:
            returns: Return series
            
        Returns:
            Maximum drawdown series
        """
        cumulative = (1 + returns / 100).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max * 100
        
        return drawdown
    
    def analyze_carry_strategy(self,
                              fx_pair: str,
                              target_rate: str,
                              funding_rate: str,
                              holding_period: int = 21) -> Dict:
        """
        Comprehensive carry trade strategy analysis
        
        Args:
            fx_pair: FX pair column name
            target_rate: Target currency rate
            funding_rate: Funding currency rate
            holding_period: Holding period in days
            
        Returns:
            Dictionary with performance metrics
        """
        print(f"\nAnalyzing Carry Trade: {fx_pair}")
        print(f"Target Rate: {target_rate} | Funding Rate: {funding_rate}")
        print("="*60)
        
        # Calculate returns
        carry_data = self.calculate_carry_return(fx_pair, target_rate, 
                                                 funding_rate, holding_period)
        
        # Remove NaN values
        returns = carry_data['total_return'].dropna()
        
        # Performance metrics
        metrics = {
            'mean_return': returns.mean(),
            'volatility': returns.std(),
            'sharpe_ratio': returns.mean() / (returns.std() + 1e-6),
            'max_return': returns.max(),
            'min_return': returns.min(),
            'skewness': returns.skew(),
            'kurtosis': returns.kurtosis(),
            'win_rate': (returns > 0).sum() / len(returns) * 100,
            'max_drawdown': self.calculate_max_drawdown(returns).min()
        }
        
        # Print metrics
        print(f"Mean Return: {metrics['mean_return']:.4f}%")
        print(f"Volatility: {metrics['volatility']:.4f}%")
        print(f"Sharpe Ratio: {metrics['sharpe_ratio']:.4f}")
        print(f"Win Rate: {metrics['win_rate']:.2f}%")
        print(f"Max Drawdown: {metrics['max_drawdown']:.4f}%")
        print(f"Skewness: {metrics['skewness']:.4f}")
        print(f"Kurtosis: {metrics['kurtosis']:.4f}")
        
        return metrics, carry_data
    
    def plot_carry_performance(self, carry_data: pd.DataFrame, title: str = "Carry Trade Performance"):
        """
        Plot carry trade performance
        
        Args:
            carry_data: DataFrame with carry trade returns
            title: Plot title
        """
        fig, axes = plt.subplots(3, 1, figsize=(14, 10))
        
        # Cumulative returns
        cumulative_returns = (1 + carry_data['total_return'] / 100).cumprod()
        axes[0].plot(cumulative_returns.index, cumulative_returns.values, 
                    label='Cumulative Return', linewidth=2)
        axes[0].set_title(f'{title} - Cumulative Returns')
        axes[0].set_ylabel('Cumulative Return')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Return distribution
        axes[1].hist(carry_data['total_return'].dropna(), bins=50, 
                    edgecolor='black', alpha=0.7)
        axes[1].set_title('Return Distribution')
        axes[1].set_xlabel('Return (%)')
        axes[1].set_ylabel('Frequency')
        axes[1].axvline(0, color='red', linestyle='--', label='Zero Return')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # Drawdown
        drawdown = self.calculate_max_drawdown(carry_data['total_return'])
        axes[2].fill_between(drawdown.index, drawdown.values, 0, 
                            alpha=0.3, color='red')
        axes[2].plot(drawdown.index, drawdown.values, color='red', linewidth=2)
        axes[2].set_title('Drawdown')
        axes[2].set_xlabel('Date')
        axes[2].set_ylabel('Drawdown (%)')
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('../docs/carry_performance.png', dpi=300, bbox_inches='tight')
        print("\nPlot saved to: ../docs/carry_performance.png")
        plt.show()


def main():
    """
    Main execution function
    """
    # Load processed data
    print("Loading processed market data...")
    data = pd.read_csv('../data/processed/merged_market_data.csv', 
                       index_col=0, parse_dates=True)
    
    # Initialize model
    model = CarryTradeModel(data)
    
    # Analyze USD/JPY carry trade (funding in JPY, investing in USD)
    metrics_usdjpy, carry_usdjpy = model.analyze_carry_strategy(
        fx_pair='USD_JPY',
        target_rate='USD_RATE',
        funding_rate='JPY_RATE',
        holding_period=21
    )
    
    # Analyze AUD/JPY carry trade
    metrics_audjpy, carry_audjpy = model.analyze_carry_strategy(
        fx_pair='AUD_JPY',
        target_rate='AUD_RATE',
        funding_rate='JPY_RATE',
        holding_period=21
    )
    
    # Plot performance
    model.plot_carry_performance(carry_usdjpy, "USD/JPY Carry Trade")
    
    # Save results
    carry_usdjpy.to_csv('../data/processed/carry_returns_usdjpy.csv')
    carry_audjpy.to_csv('../data/processed/carry_returns_audjpy.csv')
    
    print("\n" + "="*60)
    print("Carry Trade Analysis Complete!")
    print("="*60)


if __name__ == "__main__":
    main()