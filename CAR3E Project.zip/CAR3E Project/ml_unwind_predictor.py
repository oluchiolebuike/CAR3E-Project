"""
CAR³E Machine Learning Unwind Predictor
Predicts carry trade unwind risk using ML models
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')


class CarryUnwindPredictor:
    """
    Machine learning model to predict carry trade unwind events
    """
    
    def __init__(self, data: pd.DataFrame):
        """
        Initialize predictor
        
        Args:
            data: DataFrame with market data
        """
        self.data = data
        self.scaler = StandardScaler()
        self.models = {}
        self.feature_names = []
        
    def engineer_features(self, 
                         fx_pair: str = 'USD_JPY',
                         target_rate: str = 'USD_RATE',
                         funding_rate: str = 'JPY_RATE') -> pd.DataFrame:
        """
        Engineer features for ML model
        
        Args:
            fx_pair: FX pair column name
            target_rate: Target currency rate
            funding_rate: Funding currency rate
            
        Returns:
            DataFrame with engineered features
        """
        print("Engineering features...")
        
        features = pd.DataFrame(index=self.data.index)
        
        # 1. Interest rate differential
        features['rate_diff'] = self.data[target_rate] - self.data[funding_rate]
        features['rate_diff_change'] = features['rate_diff'].diff()
        features['rate_diff_momentum'] = features['rate_diff'].diff(5)
        
        # 2. FX volatility
        fx_returns = self.data[fx_pair].pct_change()
        features['fx_volatility_5d'] = fx_returns.rolling(5).std() * np.sqrt(252) * 100
        features['fx_volatility_21d'] = fx_returns.rolling(21).std() * np.sqrt(252) * 100
        features['fx_vol_spike'] = features['fx_volatility_5d'] / features['fx_volatility_21d']
        
        # 3. FX momentum
        features['fx_return_5d'] = self.data[fx_pair].pct_change(5) * 100
        features['fx_return_21d'] = self.data[fx_pair].pct_change(21) * 100
        
        # 4. Market risk sentiment
        if 'VIX' in self.data.columns:
            features['vix'] = self.data['VIX']
            features['vix_change'] = features['vix'].diff()
            features['vix_spike'] = (features['vix'] > features['vix'].rolling(21).mean() + 
                                    2 * features['vix'].rolling(21).std()).astype(int)
        
        # 5. Equity market stress
        if 'SPX' in self.data.columns:
            spx_returns = self.data['SPX'].pct_change()
            features['spx_return_5d'] = self.data['SPX'].pct_change(5) * 100
            features['spx_volatility'] = spx_returns.rolling(21).std() * np.sqrt(252) * 100
            features['spx_drawdown'] = self._calculate_drawdown(self.data['SPX'])
        
        # 6. Yield curve signals
        if 'USD_2Y10Y_SPREAD' in self.data.columns:
            features['yield_curve_spread'] = self.data['USD_2Y10Y_SPREAD']
            features['yield_curve_inversion'] = (features['yield_curve_spread'] < 0).astype(int)
        
        # 7. Cross-asset correlations (rolling)
        if 'SPX' in self.data.columns:
            features['fx_equity_corr'] = fx_returns.rolling(21).corr(
                self.data['SPX'].pct_change()
            )
        
        # Remove NaN values
        features = features.dropna()
        
        self.feature_names = features.columns.tolist()
        print(f"Engineered {len(self.feature_names)} features")
        
        return features
    
    def _calculate_drawdown(self, series: pd.Series) -> pd.Series:
        """Calculate drawdown from peak"""
        cummax = series.expanding().max()
        drawdown = (series - cummax) / cummax * 100
        return drawdown
    
    def create_target_variable(self, 
                              fx_pair: str = 'USD_JPY',
                              threshold: float = -3.0,
                              forward_window: int = 30) -> pd.Series:
        """
        Create binary target variable for carry unwind events
        
        Args:
            fx_pair: FX pair column name
            threshold: FX return threshold to define unwind (%)
            forward_window: Forward-looking window in days
            
        Returns:
            Binary target series (1 = unwind, 0 = no unwind)
        """
        print(f"Creating target variable (threshold: {threshold}%, window: {forward_window}d)...")
        
        # Calculate forward returns
        forward_returns = self.data[fx_pair].pct_change(forward_window).shift(-forward_window) * 100
        
        # Define unwind as significant negative return
        # For funding currency appreciation (carry unwind)
        target = (forward_returns < threshold).astype(int)
        
        print(f"Unwind events: {target.sum()} ({target.mean()*100:.2f}%)")
        
        return target
    
    def train_models(self, X: pd.DataFrame, y: pd.Series) -> dict:
        """
        Train multiple ML models
        
        Args:
            X: Feature DataFrame
            y: Target variable
            
        Returns:
            Dictionary of trained models
        """
        print("\nTraining models...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # 1. Logistic Regression (interpretable)
        print("\n1. Training Logistic Regression...")
        lr_model = LogisticRegression(random_state=42, max_iter=1000, class_weight='balanced')
        lr_model.fit(X_train_scaled, y_train)
        
        # 2. Random Forest (capture non-linearities)
        print("2. Training Random Forest...")
        rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=20,
            random_state=42,
            class_weight='balanced'
        )
        rf_model.fit(X_train_scaled, y_train)
        
        # Store models
        self.models = {
            'logistic_regression': lr_model,
            'random_forest': rf_model
        }
        
        # Evaluate models
        self._evaluate_models(X_test_scaled, y_test, X_train.columns)
        
        return self.models
    
    def _evaluate_models(self, X_test, y_test, feature_names):
        """Evaluate and compare models"""
        print("\n" + "="*60)
        print("MODEL EVALUATION")
        print("="*60)
        
        for name, model in self.models.items():
            print(f"\n{name.upper()}")
            print("-" * 40)
            
            # Predictions
            y_pred = model.predict(X_test)
            y_proba = model.predict_proba(X_test)[:, 1]
            
            # Metrics
            print(classification_report(y_test, y_pred))
            print(f"ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")
            
            # Confusion matrix
            cm = confusion_matrix(y_test, y_pred)
            print(f"\nConfusion Matrix:")
            print(cm)
        
        # Feature importance (Random Forest)
        if 'random_forest' in self.models:
            self._plot_feature_importance(feature_names)
    
    def _plot_feature_importance(self, feature_names):
        """Plot feature importance from Random Forest"""
        rf_model = self.models['random_forest']
        
        # Get feature importances
        importances = rf_model.feature_importances_
        indices = np.argsort(importances)[::-1][:15]  # Top 15 features
        
        # Plot
        plt.figure(figsize=(10, 8))
        plt.barh(range(len(indices)), importances[indices])
        plt.yticks(range(len(indices)), [feature_names[i] for i in indices])
        plt.xlabel('Feature Importance')
        plt.title('Top 15 Most Important Features (Random Forest)')
        plt.tight_layout()
        plt.savefig('../docs/feature_importance.png', dpi=300, bbox_inches='tight')
        print("\nFeature importance plot saved to: ../docs/feature_importance.png")
        plt.show()
    
    def predict_unwind_probability(self, 
                                   current_data: pd.DataFrame,
                                   model_name: str = 'random_forest') -> float:
        """
        Predict unwind probability for current market conditions
        
        Args:
            current_data: DataFrame with current features
            model_name: Model to use for prediction
            
        Returns:
            Unwind probability
        """
        model = self.models[model_name]
        
        # Scale features
        X_scaled = self.scaler.transform(current_data)
        
        # Predict probability
        prob = model.predict_proba(X_scaled)[:, 1]
        
        return prob[0]


def main():
    """
    Main execution function
    """
    # Load processed data
    print("Loading processed market data...")
    data = pd.read_csv('../data/processed/merged_market_data.csv', 
                       index_col=0, parse_dates=True)
    
    # Initialize predictor
    predictor = CarryUnwindPredictor(data)
    
    # Engineer features
    features = predictor.engineer_features(
        fx_pair='USD_JPY',
        target_rate='USD_RATE',
        funding_rate='JPY_RATE'
    )
    
    # Create target variable
    target = predictor.create_target_variable(
        fx_pair='USD_JPY',
        threshold=-3.0,
        forward_window=30
    )
    
    # Align features and target
    common_index = features.index.intersection(target.index)
    X = features.loc[common_index]
    y = target.loc[common_index]
    
    # Train models
    models = predictor.train_models(X, y)
    
    # Example prediction for latest data
    latest_features = X.iloc[[-1]]
    prob = predictor.predict_unwind_probability(latest_features)
    
    print("\n" + "="*60)
    print("CURRENT UNWIND RISK ASSESSMENT")
    print("="*60)
    print(f"Unwind Probability (30-day): {prob*100:.2f}%")
    
    if prob > 0.7:
        print("⚠️  HIGH RISK: Consider reducing carry exposure")
    elif prob > 0.4:
        print("⚡ MEDIUM RISK: Monitor closely")
    else:
        print("✓  LOW RISK: Carry environment stable")
    
    print("\n" + "="*60)
    print("ML Unwind Prediction Complete!")
    print("="*60)


if __name__ == "__main__":
    main()