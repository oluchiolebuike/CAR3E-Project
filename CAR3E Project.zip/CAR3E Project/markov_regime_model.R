# =============================================================================
# CAR³E: Markov Regime-Switching Model
# Identifies carry-friendly, transitional, and crisis regimes
# =============================================================================

suppressPackageStartupMessages({
  library(MSwM)
  library(tidyverse)
  library(lubridate)
  library(ggplot2)
  library(gridExtra)
})

# =============================================================================
# PROJECT ROOT
# =============================================================================

PROJECT_ROOT <- "C:/Users/Oluchi/OneDrive - University of Cape Town/CAR3E Project"
setwd(PROJECT_ROOT)

cat("Working directory set to:\n", getwd(), "\n")

# =============================================================================
# 1. DATA LOADING
# =============================================================================

load_market_data <- function(
    filepath = "data/processed/merged_market_data.csv"
) {
  cat("\nLoading market data...\n")
  
  data <- read_csv(filepath, show_col_types = FALSE) %>%
    rename(date = 1) %>%
    mutate(date = as.Date(date))
  
  cat(sprintf(
    "Loaded %d observations (%s → %s)\n",
    nrow(data), min(data$date), max(data$date)
  ))
  
  return(data)
}

# =============================================================================
# 2. FEATURE ENGINEERING
# =============================================================================

roll_sd <- function(x, n) {
  sapply(seq_along(x), function(i) {
    if (i < n) NA else sd(x[(i - n + 1):i], na.rm = TRUE)
  })
}

engineer_regime_features <- function(data) {
  cat("\nEngineering regime features...\n")
  
  data <- data %>%
    mutate(
      rate_diff = USD_RATE - JPY_RATE,
      
      usdjpy_return = 100 * (USD_JPY / lag(USD_JPY) - 1),
      
      fx_volatility = roll_sd(usdjpy_return, 3) * sqrt(252),
      
      vix_level = if ("VIX" %in% names(data)) VIX else NA_real_
    ) %>%
    drop_na(rate_diff, fx_volatility)
  
  cat(sprintf("Retained %d usable observations\n", nrow(data)))
  return(data)
}

# =============================================================================
# 3. MARKOV REGIME-SWITCHING MODEL (robust)
# =============================================================================

fit_regime_model <- function(data, n_regimes = 3, min_rows = 10) {
  cat("\nFitting Markov regime-switching model...\n")
  
  model_data <- data %>%
    select(fx_volatility, rate_diff, vix_level) %>%
    drop_na()
  
  n_obs <- nrow(model_data)
  
  if (n_obs < min_rows) {
    warning(
      sprintf(
        "Not enough data to fit full regime model (have %d rows, need %d). Returning NA.",
        n_obs, min_rows
      )
    )
    return(list(model = NA, data = model_data))
  }
  
  # Fit base linear model
  base_model <- lm(fx_volatility ~ rate_diff + vix_level, data = model_data)
  
  # Fit regime-switching model
  model <- tryCatch(
    msmFit(base_model, k = n_regimes, sw = rep(TRUE, 3)),
    error = function(e) {
      warning("Error fitting MSM model: ", e$message)
      return(NA)
    }
  )
  
  if (!is.na(model)) cat("✓ Model fitted successfully\n")
  
  return(list(model = model, data = model_data))
}
# =============================================================================
# 4. REGIME EXTRACTION
# =============================================================================

extract_regimes <- function(model_result) {
  cat("\nExtracting regime probabilities...\n")
  
  model <- model_result$model
  data <- model_result$data
  
  probs <- as.data.frame(model@Fit@filtProb)
  colnames(probs) <- paste0("regime_", seq_len(ncol(probs)), "_prob")
  
  data <- bind_cols(data, probs) %>%
    mutate(most_likely_regime = max.col(probs))
  
  regime_stats <- data %>%
    group_by(most_likely_regime) %>%
    summarise(
      avg_vol = mean(fx_volatility),
      avg_vix = mean(vix_level),
      n_obs = n(),
      .groups = "drop"
    ) %>%
    arrange(avg_vol) %>%
    mutate(
      regime_label = case_when(
        row_number() == 1 ~ "Risk-On / Carry-Friendly",
        row_number() == n() ~ "Crisis / Unwind",
        TRUE ~ "Transitional"
      )
    )
  
  data <- left_join(
    data,
    regime_stats %>% select(most_likely_regime, regime_label),
    by = "most_likely_regime"
  )
  
  print(regime_stats)
  
  return(list(
    data = data,
    regime_stats = regime_stats
  ))
}

# =============================================================================
# 5. VISUALIZATION
# =============================================================================

plot_regimes <- function(regime_result) {
  cat("\nCreating regime visualisations...\n")
  
  data <- regime_result$data
  
  prob_cols <- grep("regime_.*_prob", names(data), value = TRUE)
  
  p1 <- data %>%
    select(all_of(prob_cols)) %>%
    mutate(t = seq_len(n())) %>%
    pivot_longer(-t) %>%
    ggplot(aes(t, value, color = name)) +
    geom_line() +
    labs(title = "Regime Probabilities", y = "Probability") +
    theme_minimal()
  
  p2 <- ggplot(
    data,
    aes(factor(most_likely_regime), fx_volatility, fill = regime_label)
  ) +
    geom_boxplot() +
    labs(title = "FX Volatility by Regime") +
    theme_minimal()
  
  combined <- grid.arrange(p1, p2, ncol = 1)
  
  ggsave(
    "docs/regime_analysis.png",
    combined,
    width = 10,
    height = 8,
    dpi = 300
  )
  
  cat("✓ Plot saved to docs/regime_analysis.png\n")
}

# =============================================================================
# 6. MAIN EXECUTION
# =============================================================================

main <- function() {
  data <- load_market_data()
  data <- engineer_regime_features(data)
  
  model_result <- fit_regime_model(data)
  regime_result <- extract_regimes(model_result)
  
  plot_regimes(regime_result)
  
  write_csv(
    regime_result$data,
    "data/processed/regime_classification.csv"
  )
  
  cat("\n✓ Regime analysis completed successfully\n")
}

if (sys.nframe() == 0) {
  main()
}
