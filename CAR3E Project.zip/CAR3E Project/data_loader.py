"""
CAR³E Data Loading Pipeline
Loads and prepares macro-financial data for carry trade analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Tuple
import yfinance as yf
import warnings
warnings.filterwarnings('ignore')


class CarreeDataLoader:
    """
    Main data loader for CAR³E system
    Fetches FX rates, interest rates, volatility indices, and equity data
    """
    
    def __init__(self, start_date: str = '2015-01-01', end_date: str = None):
        """
        Initialize data loader
        
        Args:
            start_date: Start date in 'YYYY-MM-DD' format
            end_date: End date in 'YYYY-MM-DD' format (default: today)
        """
        self.start_date = start_date
        self.end_date = end_date if end_date else datetime.now().strftime('%Y-%m-%d')
        
    def load_fx_data(self) -> pd.DataFrame:
        """
        Load FX spot rates for major carry trade pairs
        
        Returns:
            DataFrame with FX rates
        """
        print("Loading FX data...")
        
        # Major carry trade pairs
        fx_pairs = {
            'USDJPY=X': 'USD_JPY',
            'AUDJPY=X': 'AUD_JPY',
            'MXNJPY=X': 'MXN_JPY',
            'EURUSD=X': 'EUR_USD',
            'GBPUSD=X': 'GBP_USD'
        }
        
        fx_data = pd.DataFrame()
        
        for ticker, col_name in fx_pairs.items():
            try:
                data = yf.download(ticker, start=self.start_date, end=self.end_date, progress=False)
                fx_data[col_name] = data['Close']
            except Exception as e:
                print(f"Warning: Could not load {ticker}: {e}")
                
        return fx_data
    
    def load_volatility_data(self) -> pd.DataFrame:
        """
        Load volatility indices
        
        Returns:
            DataFrame with volatility metrics
        """
        print("Loading volatility data...")
        
        vol_tickers = {
            '^VIX': 'VIX',
            'DX-Y.NYB': 'DXY'  # Dollar Index
        }
        
        vol_data = pd.DataFrame()
        
        for ticker, col_name in vol_tickers.items():
            try:
                data = yf.download(ticker, start=self.start_date, end=self.end_date, progress=False)
                vol_data[col_name] = data['Close']
            except Exception as e:
                print(f"Warning: Could not load {ticker}: {e}")
                
        return vol_data
    
    def load_equity_data(self) -> pd.DataFrame:
        """
        Load equity indices for risk sentiment
        
        Returns:
            DataFrame with equity prices
        """
        print("Loading equity data...")
        
        equity_tickers = {
            '^GSPC': 'SPX',      # S&P 500
            '^N225': 'NIKKEI',   # Nikkei 225
            '^FTSE': 'FTSE',     # FTSE 100
            'EWJ': 'EWJ'         # Japan ETF
        }
        
        equity_data = pd.DataFrame()
        
        for ticker, col_name in equity_tickers.items():
            try:
                data = yf.download(ticker, start=self.start_date, end=self.end_date, progress=False)
                equity_data[col_name] = data['Close']
            except Exception as e:
                print(f"Warning: Could not load {ticker}: {e}")
                
        return equity_data
    
    def generate_synthetic_rates(self) -> pd.DataFrame:
        """
        Generate synthetic interest rate data (placeholder for real central bank data)
        In production, this would connect to FRED, Bloomberg, or Reuters
        
        Returns:
            DataFrame with interest rates
        """
        print("Generating synthetic interest rate data...")
        print("NOTE: In production, connect to FRED API or Bloomberg for real rates")
        
        # Create date range
        date_range = pd.date_range(start=self.start_date, end=self.end_date, freq='D')
        
        # Synthetic rates (realistic ranges)
        rates_data = pd.DataFrame({
            'JPY_RATE': np.random.uniform(-0.1, 0.5, len(date_range)),  # BOJ rates
            'USD_RATE': np.random.uniform(0.5, 5.5, len(date_range)),   # Fed rates
            'AUD_RATE': np.random.uniform(0.75, 4.5, len(date_range)),  # RBA rates
            'EUR_RATE': np.random.uniform(-0.5, 4.0, len(date_range)),  # ECB rates
            'GBP_RATE': np.random.uniform(0.1, 5.25, len(date_range))   # BOE rates
        }, index=date_range)
        
        # Add yield curve spreads
        rates_data['USD_2Y10Y_SPREAD'] = np.random.uniform(-0.5, 2.5, len(date_range))
        rates_data['JPY_2Y10Y_SPREAD'] = np.random.uniform(-0.2, 1.0, len(date_range))
        
        return rates_data
    
    def load_all_data(self) -> Dict[str, pd.DataFrame]:
        """
        Load all datasets and return as dictionary
        
        Returns:
            Dictionary containing all datasets
        """
        print(f"\n{'='*60}")
        print("CAR³E Data Loading Pipeline")
        print(f"Date Range: {self.start_date} to {self.end_date}")
        print(f"{'='*60}\n")
        
        data = {
            'fx': self.load_fx_data(),
            'volatility': self.load_volatility_data(),
            'equity': self.load_equity_data(),
            'rates': self.generate_synthetic_rates()
        }
        
        print(f"\n{'='*60}")
        print("Data Loading Complete!")
        print(f"{'='*60}")
        
        for name, df in data.items():
            print(f"{name.upper()}: {len(df)} rows, {len(df.columns)} columns")
            
        return data
    
    def merge_datasets(self, data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        Merge all datasets into single DataFrame
        
        Args:
            data: Dictionary of DataFrames
            
        Returns:
            Merged DataFrame
        """
        print("\nMerging datasets...")
        
        # Start with FX data
        merged = data['fx'].copy()
        
        # Merge other datasets
        for key in ['volatility', 'equity', 'rates']:
            if key in data:
                merged = merged.join(data[key], how='outer')
        
        # Forward fill missing values (common in financial data)
        merged = merged.fillna(method='ffill')
        
        # Drop rows with any remaining NaN
        merged = merged.dropna()
        
        print(f"Merged dataset: {len(merged)} rows, {len(merged.columns)} columns")
        
        return merged


def main():
    """
    Main execution function
    """
    # Initialize loader
    loader = CarreeDataLoader(start_date='2020-01-01')
    
    # Load all data
    datasets = loader.load_all_data()
    
    # Merge into single dataset
    merged_data = loader.merge_datasets(datasets)
    
    # Save to CSV
    output_path = '../data/processed/merged_market_data.csv'
    merged_data.to_csv(output_path)
    print(f"\nData saved to: {output_path}")
    
    # Display summary statistics
    print("\n" + "="*60)
    print("Summary Statistics")
    print("="*60)
    print(merged_data.describe())
    
    return merged_data


if __name__ == "__main__":
    data = main()