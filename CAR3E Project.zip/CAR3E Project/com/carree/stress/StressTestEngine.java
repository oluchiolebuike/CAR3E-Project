package com.carree.stress;

import java.util.*;
import java.util.concurrent.*;
import java.io.*;

/**
 * CAR³E High-Performance Stress Testing Engine
 * Monte Carlo simulation for carry trade risk scenarios
 */
public class StressTestEngine {
    
    private static final int NUM_SIMULATIONS = 10000;
    private static final int TIME_HORIZON_DAYS = 252; // 1 year
    private static final Random random = new Random(42);
    
    /**
     * Represents a carry trade position
     */
    static class CarryPosition {
        String name;
        double notionalSize;
        double rateDifferential;
        double currentFxRate;
        double volatility;
        
        public CarryPosition(String name, double notionalSize, double rateDiff, 
                           double fxRate, double vol) {
            this.name = name;
            this.notionalSize = notionalSize;
            this.rateDifferential = rateDiff;
            this.currentFxRate = fxRate;
            this.volatility = vol;
        }
    }
    
    /**
     * Stress scenario parameters
     */
    static class StressScenario {
        String name;
        double rateShock;        // Interest rate shock (bps)
        double volShock;         // Volatility multiplier
        double fxShock;          // FX rate shock (%)
        double correlation;      // Cross-asset correlation
        
        public StressScenario(String name, double rateShock, double volShock,
                            double fxShock, double correlation) {
            this.name = name;
            this.rateShock = rateShock;
            this.volShock = volShock;
            this.fxShock = fxShock;
            this.correlation = correlation;
        }
    }
    
    /**
     * Simulation result
     */
    static class SimulationResult {
        double[] returns;
        double maxDrawdown;
        double var95;
        double cvar95;
        double marginCallProb;
        
        public SimulationResult(int size) {
            this.returns = new double[size];
        }
    }
    
    /**
     * Main stress testing method
     */
    public static void main(String[] args) {
        System.out.println("=".repeat(70));
        System.out.println("CAR³E STRESS TESTING ENGINE");
        System.out.println("High-Performance Monte Carlo Simulation");
        System.out.println("=".repeat(70));
        System.out.println();
        
        // Define carry trade positions
        List<CarryPosition> positions = createSamplePositions();
        
        // Define stress scenarios
        List<StressScenario> scenarios = createStressScenarios();
        
        // Run stress tests for each scenario
        for (StressScenario scenario : scenarios) {
            System.out.println("\n" + "=".repeat(70));
            System.out.println("SCENARIO: " + scenario.name);
            System.out.println("=".repeat(70));
            
            long startTime = System.currentTimeMillis();
            
            SimulationResult result = runMonteCarloSimulation(
                positions, scenario, NUM_SIMULATIONS
            );
            
            long endTime = System.currentTimeMillis();
            
            printResults(result, endTime - startTime);
        }
        
        System.out.println("\n" + "=".repeat(70));
        System.out.println("STRESS TESTING COMPLETE");
        System.out.println("=".repeat(70));
    }
    
    /**
     * Create sample carry trade positions
     */
    private static List<CarryPosition> createSamplePositions() {
        List<CarryPosition> positions = new ArrayList<>();
        
        positions.add(new CarryPosition("USD/JPY Carry", 10_000_000, 4.5, 145.0, 8.5));
        positions.add(new CarryPosition("AUD/JPY Carry", 5_000_000, 3.2, 98.5, 12.3));
        positions.add(new CarryPosition("MXN/JPY Carry", 3_000_000, 6.8, 8.2, 15.7));
        
        return positions;
    }
    
    /**
     * Create stress test scenarios
     */
    private static List<StressScenario> createStressScenarios() {
        List<StressScenario> scenarios = new ArrayList<>();
        
        // Scenario 1: BOJ Policy Shock
        scenarios.add(new StressScenario(
            "BOJ Rate Hike (50bps)",
            50.0,    // 50 bps rate increase
            2.5,     // 2.5x volatility spike
            -5.0,    // 5% JPY appreciation
            0.8      // High correlation
        ));
        
        // Scenario 2: USD Funding Squeeze
        scenarios.add(new StressScenario(
            "USD Funding Crisis",
            -100.0,  // 100 bps rate decrease
            3.0,     // 3x volatility spike
            -8.0,    // 8% adverse FX move
            0.9      // Very high correlation
        ));
        
        // Scenario 3: Global Risk-Off
        scenarios.add(new StressScenario(
            "Global Risk-Off Event",
            0.0,     // No rate change
            4.0,     // 4x volatility spike
            -10.0,   // 10% adverse move
            0.95     // Extreme correlation
        ));
        
        // Scenario 4: Moderate Stress
        scenarios.add(new StressScenario(
            "Moderate Market Stress",
            20.0,    // 20 bps rate increase
            1.5,     // 1.5x volatility
            -3.0,    // 3% adverse move
            0.6      // Moderate correlation
        ));
        
        return scenarios;
    }
    
    /**
     * Run Monte Carlo simulation
     */
    private static SimulationResult runMonteCarloSimulation(
            List<CarryPosition> positions,
            StressScenario scenario,
            int numSims) {
        
        System.out.println("Running " + numSims + " Monte Carlo simulations...");
        
        SimulationResult result = new SimulationResult(numSims);
        double[] portfolioReturns = new double[numSims];
        int marginCalls = 0;
        
        // Parallel execution for performance
        ExecutorService executor = Executors.newFixedThreadPool(
            Runtime.getRuntime().availableProcessors()
        );
        
        List<Future<Double>> futures = new ArrayList<>();
        
        for (int i = 0; i < numSims; i++) {
            final int simNum = i;
            futures.add(executor.submit(() -> 
                simulateSinglePath(positions, scenario, simNum)
            ));
        }
        
        // Collect results
        for (int i = 0; i < numSims; i++) {
            try {
                double pathReturn = futures.get(i).get();
                portfolioReturns[i] = pathReturn;
                
                // Check for margin call (loss > 20%)
                if (pathReturn < -20.0) {
                    marginCalls++;
                }
            } catch (Exception e) {
                System.err.println("Simulation error: " + e.getMessage());
            }
        }
        
        executor.shutdown();
        
        // Calculate risk metrics
        result.returns = portfolioReturns;
        result.maxDrawdown = calculateMaxDrawdown(portfolioReturns);
        result.var95 = calculateVaR(portfolioReturns, 0.95);
        result.cvar95 = calculateCVaR(portfolioReturns, 0.95);
        result.marginCallProb = (double) marginCalls / numSims * 100;
        
        return result;
    }
    
    /**
     * Simulate single Monte Carlo path
     */
    private static double simulateSinglePath(
            List<CarryPosition> positions,
            StressScenario scenario,
            int seed) {
        
        Random pathRandom = new Random(seed);
        double portfolioValue = 0.0;
        
        for (CarryPosition pos : positions) {
            // Apply scenario shocks
            double adjustedVol = pos.volatility * scenario.volShock;
            double adjustedRate = pos.rateDifferential + scenario.rateShock / 100.0;
            
            // Generate correlated random returns
            double fxReturn = 0.0;
            
            for (int t = 0; t < TIME_HORIZON_DAYS; t++) {
                // Geometric Brownian Motion
                double dt = 1.0 / 252.0;
                double drift = adjustedRate * dt;
                double diffusion = adjustedVol / 100.0 * Math.sqrt(dt) * pathRandom.nextGaussian();
                
                // Add scenario shock
                if (t == 0) {
                    diffusion += scenario.fxShock / 100.0;
                }
                
                fxReturn += drift + diffusion;
            }
            
            // Calculate position P&L
            double positionReturn = fxReturn * 100; // Convert to percentage
            portfolioValue += positionReturn * (pos.notionalSize / 18_000_000); // Weight
        }
        
        return portfolioValue;
    }
    
    /**
     * Calculate maximum drawdown
     */
    private static double calculateMaxDrawdown(double[] returns) {
        double maxDrawdown = 0.0;
        double peak = 0.0;
        double cumReturn = 0.0;
        
        for (double ret : returns) {
            cumReturn += ret;
            if (cumReturn > peak) {
                peak = cumReturn;
            }
            double drawdown = peak - cumReturn;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }
        
        return maxDrawdown;
    }
    
    /**
     * Calculate Value at Risk (VaR)
     */
    private static double calculateVaR(double[] returns, double confidence) {
        double[] sorted = returns.clone();
        Arrays.sort(sorted);
        
        int index = (int) ((1 - confidence) * sorted.length);
        return sorted[index];
    }
    
    /**
     * Calculate Conditional Value at Risk (CVaR / Expected Shortfall)
     */
    private static double calculateCVaR(double[] returns, double confidence) {
        double var = calculateVaR(returns, confidence);
        
        double sum = 0.0;
        int count = 0;
        
        for (double ret : returns) {
            if (ret <= var) {
                sum += ret;
                count++;
            }
        }
        
        return count > 0 ? sum / count : 0.0;
    }
    
    /**
     * Print simulation results
     */
    private static void printResults(SimulationResult result, long executionTime) {
        System.out.println("\nRISK METRICS:");
        System.out.println("-".repeat(70));
        System.out.printf("Mean Return:           %8.2f%%\n", 
            Arrays.stream(result.returns).average().orElse(0.0));
        System.out.printf("Std Deviation:         %8.2f%%\n",
            calculateStdDev(result.returns));
        System.out.printf("Max Drawdown:          %8.2f%%\n", result.maxDrawdown);
        System.out.printf("VaR (95%%):             %8.2f%%\n", result.var95);
        System.out.printf("CVaR (95%%):            %8.2f%%\n", result.cvar95);
        System.out.printf("Margin Call Prob:      %8.2f%%\n", result.marginCallProb);
        System.out.println("-".repeat(70));
        System.out.printf("Execution Time:        %8d ms\n", executionTime);
        
        // Risk assessment
        System.out.println("\nRISK ASSESSMENT:");
        if (result.marginCallProb > 10) {
            System.out.println("⚠️  SEVERE RISK: High probability of forced liquidation");
        } else if (result.marginCallProb > 5) {
            System.out.println("⚡ HIGH RISK: Significant margin call risk");
        } else if (result.marginCallProb > 1) {
            System.out.println("⚠️  MEDIUM RISK: Manageable but elevated");
        } else {
            System.out.println("✓  LOW RISK: Within acceptable parameters");
        }
    }
    
    /**
     * Calculate standard deviation
     */
    private static double calculateStdDev(double[] values) {
        double mean = Arrays.stream(values).average().orElse(0.0);
        double variance = Arrays.stream(values)
            .map(x -> Math.pow(x - mean, 2))
            .average()
            .orElse(0.0);
        return Math.sqrt(variance);
    }
}